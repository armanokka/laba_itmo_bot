self.addEventListener('install', (event) => {
  // prevents the waiting, meaning the service worker activates
  // as soon as it's finished installing
  // NOTE: don't use this if you don't want your sw to control pages
  // that were loaded with an older version
  self.skipWaiting();

  event.waitUntil((async () => {
    try {
      // self.cacheName and self.contentToCache are imported via a script
      const cache = await caches.open(self.cacheName);
      const total = self.contentToCache.length;
      let installed = 0;

      await Promise.all(self.contentToCache.map(async (url) => {
        let controller;

        try {
          controller = new AbortController();
          const { signal } = controller;
          // the cache option set to reload will force the browser to
          // request any of these resources via the network,
          // which avoids caching older files again
          const req = new Request(url, { cache: 'reload' });
          const res = await fetch(req, { signal });

          if (res && res.status === 200) {
            await cache.put(req, res.clone());
            installed += 1;
          } else {
            console.log(`unable to fetch ${url} (${res.status})`);
          }
        } catch (e) {
          console.log(`unable to fetch ${url}, ${e.message}`);
          // abort request in any case
          controller.abort();
        }
      }));

      if (installed === total) {
        console.log(`application successfully installed (${installed}/${total} files added in cache)`);
      } else {
        console.log(`application partially installed (${installed}/${total} files added in cache)`);
      }
    } catch (e) {
      console.log(`unable to install application, ${e.message}`);
    }
  })());
});

self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((response) => response || fetch(e.request)),
  );
});

self.addEventListener("push", e => {
  const data = e.data.json();
  self.registration.showNotification(
      data.title, // title of the notification
      {
          body: data.text, //the body of the push notification
          image: data.image,
          icon: data.icon // icon 
      }
  )
})

self.addEventListener('notificationclick', function(event) {
  let url = 'https://crystalplus.site/'
  event.notification.close()
  event.waitUntil(
    clients.openWindow(url)
  )
})