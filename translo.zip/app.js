import { createServer } from "./server.js"
import { Server } from "socket.io"
import pkg from './package.json' assert { type: 'json' }
import config from './config.json' assert { type: 'json' }

function getPkgVer(name) {
  let version = pkg.dependencies[name] || pkg.devDependencies[name] || ''
  return version.replace('^', '')
}

console.log('Добро пожаловать на веб-сервер Translo Web')
console.log(`Vue: ${getPkgVer('vue')} | Vuex: ${getPkgVer('vuex')} | Vite: ${getPkgVer('vite')}`)

;(async () => {

const { app, vite } = await createServer()

let server = app.listen(config.port, () => {
  console.log(`Сайт доступен по адресу http://localhost:${config.port}`)
})

})()