import { defineConfig } from 'vite'
import vuePlugin from '@vitejs/plugin-vue'
import path from 'node:path'
import url from 'url'

const base = '/'
const dirname = url.fileURLToPath(new URL('.', import.meta.url))
console.log('dirname', dirname)

export default defineConfig(({ command, ssrBuild }) => ({
  base,
  resolve: {
    alias: {
      '@': path.resolve(dirname, './src'),
    },
  },
  plugins: [
    vuePlugin()
  ],
  build: {
    minify: 'terser',
    terserOptions: {
      output: {
        comments: false,
      },
    },
  }
}))
