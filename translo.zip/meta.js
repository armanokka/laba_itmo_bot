import seo from './seo.js'

export default function getMetaTags(url) {
  let html = ''
  for (let [key, value] of Object.entries(seo[url].metaTags)) {
    html += `    <meta name="${key}" content="${value}"/>\n`
  }
  for (let [key, value] of Object.entries(seo[url].og)) {
    html += `    <meta property="${key}" content="${value}"/>\n`
  }
  return html
}