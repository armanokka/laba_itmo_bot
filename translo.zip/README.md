# Translo Web

by kotik_admin

порт веб-сервера указан в config.json

### Установить зависимости
```
npm install
```

### Билд (Создать bundle сайта для прода)
```
npm run build
```

### Запустить проект в режиме разработки
```
node app
```

### Запустить проект в режиме прода
```
NODE_ENV=production node app
```