export default {
  '/': {
    title: 'Translo Web',
    metaTags: {
      keywords: 'translo web',
      description: 'Translo Web',
    },
    og: {
      'og:title': 'Translo Web',
      'og:site_name': 'Translo Web',
      'og:description': 'Translo Web'
    }
  },
}