import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import seo from './seo.js'
import getMetaTags from './meta.js'
import url from 'url'
import axios from 'axios'
import express from 'express'
import compression from 'compression'
import serveStatic from 'serve-static'
import config from './config.json' assert { type: 'json' }

const resolve = (p) => path.resolve(__dirname, p)
const isTest = process.env.NODE_ENV === 'test' || !!process.env.VITE_TEST_BUILD
const isProd = process.env.NODE_ENV === 'production'
const root = process.cwd()
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const base = '/'
const prodPath = config.SSR ? 'dist/client' : 'dist'
const indexProd = fs.readFileSync(resolve(`${prodPath}/index.html`), 'utf-8')
const indexDev = fs.readFileSync(resolve('index.html'), 'utf-8')

console.log('Режим production: ', isProd)

const app = express()

app.set('trust proxy', true)
app.disable('x-powered-by')
app.use(compression())

export async function createServer(hmrPort) {
  let vite
  if (!isProd) {
    vite = await (
      await import('vite')
    ).createServer({
      base: '/',
      root,
      logLevel: isTest ? 'error' : 'info',
      server: {
        middlewareMode: true,
        watch: {
          // During tests we edit the files too fast and sometimes chokidar
          // misses change events, so enforce polling for consistency
          usePolling: true,
          interval: 100
        },
        hmr: {
          port: hmrPort
        }
      },
      appType: 'custom'
    })
    // use vite's connect instance as middleware
    app.use(vite.middlewares)
    app.use(serveStatic(__dirname + "/_public"))
    app.use(express.static(prodPath, {index: false}))
  } else {
    app.use((await import('compression')).default())
    app.use(serveStatic(__dirname + "/_public"))
    app.use(
      base,
      (await import('serve-static')).default(resolve(prodPath), {
        index: false
      })
    )
  }

  app.get(config.singlePage ? '/' : '*', async (req, res) => {
    try {
      res.header('Cache-control', 'no-cache, no-store')
      res.header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload')
      res.header('X-XSS-Protection', '1; mode=block')
      res.header('X-Frame-Options', 'DENY')
      res.header('X-Content-Type-Options', 'nosniff')
      res.type('html')
      let url = req.originalUrl
      if (url.endsWith('/') && config.SSR) url = url.slice(0, -1)
      let template, render
      if (isProd) {
        template = indexProd
        if (config.SSR) {
          render = (await import('./dist/server/entry-server.js')).render
        }
      } else {
        template = indexDev
        template = await vite.transformIndexHtml(url, template)
        if (config.SSR) {
          let start = new Date()
          console.log('start loading SSR module')
          render = (await vite.ssrLoadModule('/src/entry-server.js')).render
          let finish = new Date()
          let total = (finish-start)/1000
          console.log(`finish loading SSR module: ${total} s`)
        }
      }

      if (config.SSR) {
        const [appHtml, preloadLinks] = await render(url, manifest)

        template = template
          .replace(`<!--preload-links-->`, preloadLinks)
          .replace(`<!--app-html-->`, appHtml) 
      }

      if (seo[url]) {
        template = template
        .replace(`<!--app-title-->`, `<title>${seo[url].title}</title>`)
        .replace(`<!--app-meta-->`, getMetaTags(url))
      }

      res.status(200).set({ 'Content-Type': 'text/html' }).end(template)
    } catch (e) {
      vite && vite.ssrFixStacktrace(e)
      console.log(e.stack)
      res.status(500).end(e.stack)
    }
  })

  app.use('/assets*', (req, res, next) => {
    res.header('Cache-Control', 'max-age=2592000')
    next()
  })

  return { app, vite }
}
