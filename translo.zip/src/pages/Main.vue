<template>
  <div class="main">
    <div class="flex gap-2 justify-center" ref="title">
      <img
      :class="{
        logo: true,
        'rotate-hover': animateLogo === true,
        'rotate-leave': animateLogo === false
      }"
      @mouseenter="animateLogo = true"
      @mouseleave="animateLogo = false"
      ref="logo"
      :src="'translo.png'" alt="" width="80"
        height="80">
      <h1 class="title">Translo</h1>
    </div>
    <div class="container">
      <div class="card">
        <translate />
      </div>
      <div class="card" v-if="synonyms.length != 0">
          <synonyms :value="synonyms" />
        </div>
        <div class="card" v-if="reverse_translations">
          <reverse-translations :value="reverse_translations" />
        </div>
    </div>
    <translo-footer />
  </div>
</template>

<script>
import Translate from '@/components/Translate.vue'
import Synonyms from '@/components/Synonyms.vue'
import ReverseTranslations from '@/components/ReverseTranslations.vue'
import Dictionary from '@/components/Dictionary.vue'
import Footer from '@/components/Footer.vue'
import '@/webapp.js'

export default {
  components: {
    'translo-footer': Footer,
    'translate': Translate,
    'synonyms': Synonyms,
    'reverse-translations': ReverseTranslations,
    'dictionary': Dictionary
  },
  data() {
    return {
      animateLogo: null,
      reverse_translations: null,
      dictionary: [],
      synonyms: [],
      webApp: {}
    }
  },
  methods: {
    setDictionary(dictionary, reverse_translations, synonyms) {
      this.dictionary = dictionary
      this.reverse_translations = reverse_translations
      this.synonyms = synonyms
    },
  },
  mounted() {
    if (window.Telegram) {
      this.webApp = window.Telegram.WebApp
      this.$refs.title.classList.add('hidden')
      setInterval(() => {
        if (this.webApp.viewportHeight > 500) {
          this.$refs.title.classList.remove('hidden')
        } else {
          this.$refs.title.classList.add('hidden')
        }
      }, 500)
    }
    let theme = this.webApp.themeParams
    let style = ''
    if (theme.bg_color) {
      style += `--bg-color: ${theme.bg_color};`
      style += `--bg-color-2: ${theme.secondary_bg_color};`
    }
    if (this.webApp.colorScheme == 'dark') {
      style += `--button-color: #070707;`
      style += `--text-color: white;`
    }
    document.body.style = style
  },
};
</script>

<style>
.dictionary-cards {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

@media only screen and (min-width: 1000px) {
  .dictionary-cards {
    flex-direction: row;
  }
}
</style>
