<template>
  <router-view/>
</template>

<style lang="scss">

@import '@/assets/fonts/material-icons/fonts.css';
@import '@/assets/fonts/rubik/fonts.css';
@import '@/style.css';


</style>
