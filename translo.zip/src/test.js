import languages from './languages.js'
import languagesAll from './languages-all.js'

function getLangNames(userlangs) {
  let codes = []
  let names = {
    'auto': ['Auto']
  }
  for (let [lang, code] of Object.entries(languages)) {
    codes.push(code)
    names[code] = [lang]
  }
  if (userlangs) {
    for (let userlang of userlangs) {
      for (let [code, lang] of Object.entries(languagesAll[userlang])) {
        if (!names[code]) continue
        if (names[code].includes(lang)) continue
        names[code].push(lang)
      }
    }
  }
  return names
}

function getSearchList(userlang) {
  let langNames = getLangNames(userlang)
  let list = {}
  for (let [code, names] of Object.entries(langNames)) {
    for (let name of names) {
      list[name] = code
    }
  }
  return list
}

function searchLang(text, userlang) {
  text = text.toLowerCase()
  let searchList = getSearchList(userlang)
  let list = Object.entries(searchList)
  let codes = []
  let matching = list.filter(x => x[0].toLowerCase().includes(text))
  for (let [name, code] of matching) {
    if (!codes.includes(code)) {
      codes.push(code)
    }
  }
  return codes
}

//console.log(searchLang('бело'))