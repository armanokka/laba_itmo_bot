<template>
  <div class="footer">
    <div class="app-author text-center">Translo Web by
      <a href="https://t.me/kotik_admin" target="_blank">@kotik_admin</a>
    </div>
  </div>
</template>

<script>

export default {
  name: 'translo-footer'
}

</script>

<style>
.footer {
  width: 100%;
  padding: 20px;
  color: gray;
}
</style>