<template>
  <div class="translate-wrapper">
    <div class="translate-buttons-wrapper">
      <div class="flex-wrap gap-1 translate-buttons">
        <slot name="icons"></slot>
      </div>
    </div>
    <textarea @input="emitInput" @click="emitClick" :value="value"></textarea>
  </div>
</template>

<script>

export default {
  props: ['value'],
  methods: {
    emitInput(event) {
      this.$emit('value', event.target.value)
    },
    emitClick(event) {
      window.scrollTo({ top: 0 })
      setTimeout(() => {
        window.scrollTo({ top: 0 })
      }, 500)
    }
  }
}

</script>

<style>
.translate-wrapper {
  width: 100%;
  padding: 5px;
}

.translate-buttons-wrapper {
  position: relative;
}

.translate-buttons {
  position: absolute;
  right: 0;
  padding: 5px;
}

textarea {
  width: 100%;
  height: 150px;
  font-size: 18px;
  border: none;
  outline: none;
  resize: none;
  padding-right: 50px;
  caret-color: var(--primary-color);
  color: var(--text-color);
  background-color: transparent;
}
</style>