<template>
  <div>
    <div class="lang-tabs">
      <tabs>
        <tab v-for="lang, index of getRecentFrom" :key="lang" :class="{
          first: index == 0,
          last: index == getRecentFrom.length - 1,
          active: lang == from
        }" @click="switchListFromState()">{{ lang }}</tab>
      </tabs>
      <button :class="{
        'btn round expand-btn': true,
        'active': listFromState
      }" v-show="!this.mobileView" @click="switchListFromState">
        <i class="material-icons">expand_more</i>
      </button>
      <button class="btn round switch-btn" ref="switchLang" @click="switchLang">
        <i class="material-icons">sync_alt</i>
      </button>
      <button :class="{
        'btn round expand-btn': true,
        'active': listToState
      }" v-show="!this.mobileView" @click="switchListToState">
        <i class="material-icons">expand_more</i>
      </button>
      <tabs>
        <tab v-for="lang, index of getRecentTo" :key="lang" :class="{
          first: index == 0,
          last: index == getRecentTo.length - 1,
          active: lang == to
        }" @click="switchListToState()">{{ lang }}</tab>
      </tabs>
    </div>
    <div class="select-wrapper" ref="selectWrapper">
      <languages-list
        :list="listFrom"
        :state="listFromState"
        :recent="recentFrom"
        @selectLang="switchFrom"
      />
      <languages-list
        :list="listTo"
        :state="listToState"
        :recent="recentTo"
        @selectLang="switchTo"
      />
    </div>
    <div class="adaptive-area">
      <translate-area
        @click="hideLangsList()"
        @value="translate"
        :value="translateText"
      >
        <template v-slot:icons>
          <button class="icon-button"
            v-if="translateText"
            @click="clear"
          ><i class="material-icons">close</i></button>
        </template>
      </translate-area>
      <div class="divider"></div>
      <translate-area
        @click="hideLangsList()"
        :value="translatedText"
      >
        <template v-slot:icons>
          <button class="icon-button"
            @click="copy(translatedText)"
          ><i class="material-icons">content_copy</i></button>
        </template>
      </translate-area>

    </div>
  </div>
</template>

<script>

import Tabs from '@/components/Tabs.vue'
import Tab from '@/components/Tab.vue'
import TranslateArea from '@/components/TranslateArea.vue'
import LanguagesList from '@/components/LanguagesList.vue'
import languages from '@/languages.js'

export default {
  data() {
    return {
      rotate: false,
      mobileView: true,
      from: 'Auto',
      to: 'Russian',
      recentFrom: ['Auto'],
      recentTo: ['Russian'],
      listFrom: [],
      listTo: [],
      listFromState: false,
      listToState: false,
      languages: languages,
      translateText: '',
      translatedText: '',
      domain: 'us.translo.org',
      domains: [
        'us.translo.org',
        'eu.translo.org'
      ],
      apiv: 'webapp',
      timeout: null,
    }
  },
  components: {
    'tabs': Tabs,
    'tab': Tab,
    'translate-area': TranslateArea,
    'languages-list': LanguagesList,
  },
  methods: {
    clear() {
      this.translateText = ''
      this.translatedText = ''
    },
    saveText() {
      try {
        localStorage.setItem('translo_translate_text', this.translateText)
        localStorage.setItem('translo_translated_text', this.translatedText)
      } catch {}
    },
    loadText() {
      let translate = localStorage.getItem('translo_translate_text')
      let translated = localStorage.getItem('translo_translated_text')
      console.log(translate, translated)
      if (translate) this.translate = translate
      if (translated) this.translated = translated
    },
    saveData() {
      localStorage.setItem('translo_data', JSON.stringify({
        from: this.from,
        to: this.to,
        recentFrom: this.recentFrom,
        recentTo: this.recentTo,
      }))
    },
    loadData() {
      let data = localStorage.getItem('translo_data')
      if (!data) return
      let json = JSON.parse(data)
      this.from = json.from
      this.to = json.to
      this.recentFrom = json.recentFrom,
      this.recentTo = json.recentTo
    },
    switchLang() {
      if (this.from == 'Auto') return
      let el = this.$refs.switchLang
      if (this.rotate) {
        el.classList.remove('rotate-hover')
        el.classList.add('rotate-leave')
      } else {
        el.classList.add('rotate-hover')
        el.classList.remove('rotate-leave')
      }
      this.rotate = !this.rotate
      let from = this.from
      let to = this.to
      this.translateText = this.translatedText
      this.setFrom(to)
      this.setTo(from)
      this.hideLangsList()
      this.saveData()
      this.translateRequest(this.translateText)
    },
    setFrom(lang) {
      this.from = lang
      let index = this.recentFrom.findIndex(x => x == lang)
      if (index != -1) {
        this.recentFrom.splice(index, 1)
      }
      this.recentFrom.unshift(lang)
      if (this.recentFrom.length > 6) {
        this.recentFrom.pop()
      }
    },
    setTo(lang) {
      this.to = lang
      let index = this.recentTo.findIndex(x => x == lang)
      if (index != -1) {
        this.recentTo.splice(index, 1)
      }
      this.recentTo.unshift(lang)
      if (this.recentTo.length > 6) {
        this.recentTo.pop()
      }
    },
    switchFrom(lang) {
      this.switchListFromState()
      this.setFrom(lang)
      this.saveData()
      this.translateRequest(this.translateText)
    },
    switchTo(lang) {
      this.switchListToState()
      this.setTo(lang)
      this.saveData()
      this.translateRequest(this.translateText)
    },
    hideWrapper() {
      let open = this.listFromState || this.listToState
      if (open) {
        this.$refs.selectWrapper.classList.add('open')
      } else {
        setTimeout(() => {
          this.$refs.selectWrapper.classList.remove('open')
        }, 300)
      }
    },
    switchListFromState() {
      this.listFromState = !this.listFromState
      this.listToState = false
      this.hideWrapper()
    },
    switchListToState() {
      this.listToState = !this.listToState
      this.listFromState = false
      this.hideWrapper()
    },
    hideLangsList() {
      this.listFromState = false
      this.listToState = false
      this.hideWrapper()
    },
    copy(text) {
      var input = document.createElement('textarea')
      input.innerHTML = text
      document.body.appendChild(input)
      input.select()
      var result = document.execCommand('copy')
      document.body.removeChild(input)
      return result
    },
    async pingAPI() {
      return await Promise.race(this.domains.map(domain => {
        return new Promise(resolve => {
          fetch(`https://${domain}/`)
          .then(() => {
            resolve(domain)
          })
        })
      }))
    },
    translate(text) {
      text = text.trim()
      if (text == this.translateText) return
      this.translateText = text
      if (!text) return
      if (this.timeout) {
        clearTimeout(this.timeout)
      }
      this.timeout = setTimeout(() => {
        this.translateRequest(text)
      }, 200)
    },
    async translateRequest(text) {
      if (!text) return
      let body = new URLSearchParams()
      body.append("from", this.getFromCode)
      body.append("to", this.getToCode)
      body.append("text", text)
      let request = await fetch(`https://${this.domain}/api/${this.apiv}/translate`, {
        method: 'POST',
        redirect: 'follow',
        body: body,
      })
      let response = await request.json()
      if (!response.ok) return
      this.translatedText = response.translated_text
      let { dictionary, reverse_translations, synonyms } = response
      this.$parent.setDictionary(dictionary, reverse_translations, synonyms)
    }
  },
  computed: {
    getRecentFrom() {
      if (this.mobileView) {
        return [this.from]
      } else {
        return this.recentFrom
      }
    },
    getRecentTo() {
      if (this.mobileView) {
        return [this.to]
      } else {
        return this.recentTo
      }
    },
    getFromCode() {
      if (this.from == 'Auto') return 'auto'
      return languages[this.from]
    },
    getToCode() {
      return languages[this.to]
    }
  },
  mounted() {
    this.listFrom = Object.keys(this.languages)
    this.listFrom.unshift('Auto')
    this.listTo = Object.keys(this.languages)
    this.pingAPI()
    .then(domain => {
      console.log('ping: ', domain, 'is faster')
      this.domain = domain
    })
    this.loadData()
  }
}

</script>


<style>
.lang-tabs {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 55px;
}

.lang-tabs .tabs {
  width: 100%;
  height: 100%;
}

.switch-btn {
  width: 45px;
  height: 45px;
}

.expand-btn {
  display: none;
  width: 35px;
  height: 35px;
}

.adaptive-area {
  display: flex;
  flex-direction: column;
  width: 100%;
  border-top: 1px solid lightgray;
}

.divider {
  width: 100%;
  height: 1px;
  background-color: lightgray;
}

.select-wrapper {
  padding-left: 10px;
  padding-right: 10px;
  padding-top: 0px;
  padding-bottom: 0px;
  transition: padding 0.1s;
}

.select-wrapper.open {
  padding-top: 10px;
  padding-bottom: 10px;
}

@media only screen and (min-width: 600px) {
  .adaptive-area {
    flex-direction: row;
  }

  .divider {
    min-width: 1px;
    width: 1px;
    height: auto;
  }

  .expand-btn {
    display: flex;
  }
}
</style>