<template>
  <div class="tabs">
    <slot></slot>
  </div>
</template>

<script>

export default {
  data() {
    return {
      active: null
    }
  },
  methods: {

  },
  mounted() {
    
  }
}

</script>

<style>
.tabs {
  display: flex;
}
</style>