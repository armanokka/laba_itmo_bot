<template>
  <div class="synonyms column gap-2">
    <div class="column gap-1">
      <b class="synonyms-title">Synonyms: </b>
      <div class="flex-wrap gap-1">
        <div class="badge" v-for="synonym of value">{{ synonym }}</div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  props: ['value'],
}

</script>

<style>
.synonyms {
  margin: 10px;
}

.synonyms-title {
  color: var(--primary-color);
}

.badge {
  padding: 5px;
  padding-left: 10px;
  padding-right: 10px;
  border-radius: 50px;
  background-color: var(--secondary-color);
  color: white;
  transition: background-color 0.3s;
}

.badge:hover {
  background-color: var(--primary-color);
}
</style>