<template>
  <div class="reverse-translations">
    <ol>
      <li v-for="example of value">
        <div v-html="example"></div>
      </li>
    </ol>
  </div>
</template>

<script>

export default {
  props: ['value']
}

</script>

<style>
.dictionary {
  margin: 10px;
  max-height: 250px;
  overflow-y: scroll;
}

</style>