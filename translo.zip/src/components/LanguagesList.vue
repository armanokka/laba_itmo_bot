<template>
  <div class="languages-viewbox">
    <div class="search">
      <i class="material-icons">search</i>
      <input type="text" placeholder="Language..." @input="setSearch" ref="search">
    </div>
    <div class="select-languages column gap-1">
      <div class="flex-wrap gap-1 align-center" v-if="recent">
        <div><i class="material-icons recent-icon">schedule</i></div><button
          class="btn select-btn"
          v-for="lang of recent"
          @click="selectLang(lang)"
        >{{ lang }}</button>
      </div>
      <hr noshade>
      <div class="languages gap-1">
        <button
          class="btn select-btn"
          v-for="lang of getList"
          @click="selectLang(lang)"
        >{{ lang }}</button>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  props: ['list', 'state', 'recent'],
  data() {
    return {
      search: '',
    }
  },
  methods: {
    open() {
      this.$el.classList.add('open')
      this.$refs.search.focus()
      setTimeout(() => {
        window.scrollTo({ top: 0 })
      }, 500)
    },
    hide() {
      this.$el.classList.remove('open')
      this.$refs.search.value = ''
    },
    selectLang(lang) {
      this.$emit('selectLang', lang)
    },
    setSearch(event) {
      this.search = event.target.value
    }
  },
  computed: {
    getList() {
      return this.list.filter(x => x.toLowerCase().includes(this.search.toLowerCase()))
    }
  },
  watch: {
    state(newValue, oldValue) {
      if (newValue) {
        this.open()
      } else {
        this.hide()
      }
    }
  }
}

</script>

<style>
.languages-viewbox {
  display: flex;
  flex-direction: column;
  gap: 10px;
  height: 0px;
  overflow: hidden;
  transition: height 0.5s;
}

.languages-viewbox hr {
  width: 99%;
  color: lightgray;
}

.languages-viewbox.open {
  height: 320px;
}

.languages-viewbox.hide {
  display: none;
}

.select-languages .title {
  margin-left: 10px;
}

.select-languages {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: scroll;
}

.search {
  display: flex;
  align-items: center;
  width: 100%;
  height: 50px;
  background-color: var(--bg-color);
}

.search i {
  font-size: 32px;
  margin-right: 5px;
}

.recent-icon {
  font-size: 32px;
  margin-right: 5px;
}

.search input {
  width: 100%;
  height: 100%;
  font-size: 18px;
  border: none;
  border-radius: 20px;
  outline: none;
}

.search input:focus {
  border: 2px solid var(--primary-color);
}

.search input {
  padding-left: 10px;
}

.languages {
  display: flex;
  flex-direction: column;
}


.languages .btn {
  justify-content: left;
}

@media only screen and (min-width: 1000px) {
  .languages {
    flex-direction: row;
    flex-wrap: wrap;
  }
}
</style>