<template>
  <div class="dialog-container" v-if="show" @click="hideDialog">
    <div class="dialog" @click.stop>
      <div class="dialog-title">{{ title }}</div>
      <div class="dialog-content">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "my-dialog",
  props: {
    show: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: ''
    }
  },
  methods: {
    hideDialog() {
      this.$el.classList.add('hide')
      setTimeout(() => {
        this.$emit("update:show", false);
      }, 290)
    },
  },
  mounted() {
    console.log("dialog mounted");
  },
};
</script>

<style>
.dialog-container {
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  top: 0;
  width: 100%;
  height: 100%;
  padding: 20px;
  z-index: 5;
  background-color: rgba(0, 0, 0, 0.7);
  animation: fadeIn 0.3s;
  animation-fill-mode: forwards;
}

.dialog-container.hide {
  animation: fadeOut 0.3s;
}

.dialog {
  display: grid;
  gap: 20px;
  width: 100%;
  max-width: 600px;
  padding: 10px;
  background-color: white;
  border-radius: 10px;
}

.dialog-title {
  font-size: 20px;
}

.dialog-content {
  max-height: calc(100vh - 150px);
  overflow-y: scroll;
}

.dialog-buttons {
  display: flex;
  gap: 20px;
  margin-left: auto;
}

@keyframes dialogWinOpen {
  0% {
    transform: scale(.4);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

@keyframes dialogWinClose {
  0% {
    transform: scale(1);
    opacity: 1;
  }

  100% {
    transform: scale(.4);
    opacity: 0;
  }
}

@keyframes dialogOpen {
  0% {
    background-color: rgba(0, 0, 0, 0);
  }

  100% {
    background-color: rgba(0, 0, 0, .7);
  }
}

@keyframes dialogClose {
  0% {
    background-color: rgba(0, 0, 0, .7);
  }

  100% {
    background-color: rgba(0, 0, 0, 0);
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@keyframes click {
  from {
    opacity: 1;
    transform: scale(1);
  }

  to {
    opacity: 0;
    transform: scale(6);
  }
}

@keyframes fadeOut {
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
}
</style>
