<template>
  <button class="tab" @click="this.$parent.setActiveTab">
    <slot></slot>
  </button>
</template>

<script>

export default {

}

</script>

<style>

.tab {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  background-color: transparent;
  border: none;
  font-size: 18px;
  cursor: pointer;
  transition: color 0.3s, background-color 0.3s;
}

.tab.active {
  background-color: var(--button-color);
  color: var(--primary-color);
  border-bottom: 2px solid var(--primary-color);
}

.tab.first {
  border-top-left-radius: 10px;
}

.tab.last {
  border-top-right-radius: 10px;
}

</style>