import { createApp } from 'vue'
import App from './App.vue'
import router from './router/router'
import store from './store'
//import VueTippy from 'vue-tippy'
//import 'tippy.js/dist/tippy.css'

let app = createApp(App)

/*
app.use(
  VueTippy,
  // optional
  {
    directive: 'tippy', // => v-tippy
    component: 'tippy', // => <tippy/>
    componentSingleton: 'tippy-singleton', // => <tippy-singleton/>,
    defaultProps: {
      placement: 'bottom',
      allowHTML: true,
    }, // => Global default options * see all props
  }
)
*/

app.use(store)
app.use(router)
app.mount('#app')
